<?php

namespace App\Controllers;

use App\Models\QuestionModel;
use App\Models\CategorieModel;
use CodeIgniter\Controller;

class QuizControlleur extends Controller
{
    protected $questionModel;
    protected $categorieModel;
    protected $session;

    public function __construct()
    {
        $this->questionModel = new QuestionModel();
        $this->categorieModel = new CategorieModel();
        $this->session = \Config\Services::session();
    }

    /**
     * Page d'accueil du quiz - Sélection des paramètres
     */
    public function index()
    {
        $data = [
            'title' => 'Salle Quiz',
            'categories' => $this->categorieModel->getCategoriesAvecNbQuestions()
        ];

        return view('quiz/index', $data);
    }

    /**
     * Démarre une nouvelle partie de quiz
     */
    public function demarrer()
    {
        $nbQuestions = $this->request->getPost('nb_questions') ?? 10;
        $categorieId = $this->request->getPost('categorie_id') ?? null;
        $niveauDifficulte = $this->request->getPost('niveau_difficulte') ?? null;

        // Récupérer les questions
        $questions = $this->questionModel->getQuestionsAleatoires(
            $nbQuestions,
            $categorieId,
            $niveauDifficulte
        );

        if (empty($questions)) {
            return redirect()->to('/quiz')->with('error', 'Aucune question disponible avec ces critères.');
        }

        // Initialiser la session
        $this->session->set([
            'quiz_questions' => array_column($questions, 'numero'),
            'quiz_index' => 0,
            'quiz_score' => 0,
            'quiz_reponses' => [],
            'quiz_debut' => time()
        ]);

        return redirect()->to('/quiz/question');
    }

    /**
     * Affiche la question courante
     */
    public function question()
    {
        $questions = $this->session->get('quiz_questions');
        $index = $this->session->get('quiz_index');

        if (!$questions || $index >= count($questions)) {
            return redirect()->to('/quiz/resultats');
        }

        $numeroQuestion = $questions[$index];
        $question = $this->questionModel->getQuestionComplete($numeroQuestion);

        // Mélanger les propositions
        shuffle($question['propositions']);

        $data = [
            'title' => 'Question ' . ($index + 1) . '/' . count($questions),
            'question' => $question,
            'index' => $index + 1,
            'total' => count($questions),
            'progression' => round((($index + 1) / count($questions)) * 100)
        ];

        return view('quiz/question', $data);
    }

    /**
     * Traite la réponse soumise
     */
    public function repondre()
    {
        $questions = $this->session->get('quiz_questions');
        $index = $this->session->get('quiz_index');
        $score = $this->session->get('quiz_score');
        $reponses = $this->session->get('quiz_reponses') ?? [];

        $numeroQuestion = $questions[$index];
        $numeroProposition = $this->request->getPost('proposition');

        // Vérifier la réponse
        $estCorrect = $this->questionModel->verifierReponse($numeroQuestion, $numeroProposition);

        if ($estCorrect) {
            $score++;
        }

        // Enregistrer la réponse
        $reponses[$numeroQuestion] = [
            'proposition_choisie' => $numeroProposition,
            'correct' => $estCorrect,
            'temps_reponse' => time()
        ];

        // Mettre à jour la session
        $this->session->set([
            'quiz_score' => $score,
            'quiz_index' => $index + 1,
            'quiz_reponses' => $reponses
        ]);

        // Si c'est la dernière question
        if ($index + 1 >= count($questions)) {
            return redirect()->to('/quiz/resultats');
        }

        return redirect()->to('/quiz/question');
    }

    /**
     * Affiche les résultats finaux
     */
    public function resultats()
    {
        $questions = $this->session->get('quiz_questions');
        $score = $this->session->get('quiz_score');
        $reponses = $this->session->get('quiz_reponses');
        $debut = $this->session->get('quiz_debut');

        if (!$questions) {
            return redirect()->to('/quiz');
        }

        $total = count($questions);
        $pourcentage = round(($score / $total) * 100);
        $duree = time() - $debut;

        // Récupérer les détails des questions et réponses
        $details = [];
        foreach ($questions as $numQuestion) {
            $question = $this->questionModel->getQuestionComplete($numQuestion);
            $bonnesReponses = $this->questionModel->getBonnesReponses($numQuestion);
            $reponseUtilisateur = $reponses[$numQuestion] ?? null;

            $details[] = [
                'question' => $question,
                'bonnes_reponses' => $bonnesReponses,
                'reponse_utilisateur' => $reponseUtilisateur
            ];
        }

        $data = [
            'title' => 'Résultats du Quiz',
            'score' => $score,
            'total' => $total,
            'pourcentage' => $pourcentage,
            'duree' => $duree,
            'details' => $details
        ];

        // Nettoyer la session
        $this->session->remove(['quiz_questions', 'quiz_index', 'quiz_score', 'quiz_reponses', 'quiz_debut']);

        return view('quiz/resultats', $data);
    }

    /**
     * Signaler une erreur dans une question
     */
    public function signalerErreur()
    {
        if (!$this->request->isAJAX()) {
            return redirect()->to('/quiz');
        }

        $db = \Config\Database::connect();

        $data = [
            'numero_question' => $this->request->getPost('numero_question'),
            'explication' => $this->request->getPost('explication'),
            'numero_proposition_1' => $this->request->getPost('proposition_1'),
            'numero_proposition_2' => $this->request->getPost('proposition_2'),
            'numero_proposition_3' => $this->request->getPost('proposition_3'),
            'numero_proposition_4' => $this->request->getPost('proposition_4'),
            // Si vous avez un système d'authentification, ajoutez l'id_utilisateur ici
        ];

        $db->table('log_erreurs_question')->insert($data);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Merci pour votre signalement !'
        ]);
    }
}