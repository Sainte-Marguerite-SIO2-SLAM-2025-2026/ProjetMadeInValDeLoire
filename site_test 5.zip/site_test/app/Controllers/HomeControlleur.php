<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\RedirectResponse;

class HomeControlleur extends BaseController
{

    // Constantes de configuration
    private const MIN_ROOM = 1;
    private const MAX_ROOM = 6;

    // Clés de session
    private const SESSION_CURRENT_ROOM = 'current_room';
    private const SESSION_COMPLETED_ROOMS = 'completed_rooms';
    private const SESSION_FAILED_ROOMS = 'failed_rooms';

    /**
     * Page d'accueil du manoir
     *
     * @return string
     */
    public function index(): string
    {
        $this->initSession();
        session()->set('mode', 'nuit');
        $data = [
            'current_room' => session()->get(self::SESSION_CURRENT_ROOM),
            'completed_rooms' => session()->get(self::SESSION_COMPLETED_ROOMS)
        ];

        return view('manoir_home', $data);
    }

    /**
     * Page du mode jour
     *
     * @return string
     */
    public function pagejour(): string
    {
        session()->set('mode', 'jour');
        return view('manoir_jour_home');
    }

    /**
     * Affiche une salle spécifique
     *
     * @param int $numero Numéro de la salle
     * @return string|RedirectResponse
     */
    public function salle($numero) : string|RedirectResponse
    {
        // Validation du numéro de salle
        if (!$this->salleValide($numero)) {
            return redirect()->to('/')
                ->with('error', 'Numéro de salle invalide');
        }

        // Vérification de l'existence de la vue
        $viewPath = "salle/salle_{$numero}";
        if (!$this->controleExisteView($viewPath)) {
            log_message('error', "Vue manquante : {$viewPath}");
            return redirect()->to('/')
                ->with('error', 'Salle indisponible');
        }

        $data = ['numero_salle' => $numero];

        return view($viewPath, $data);
    }

    /**
     * Valide la complétion d'une salle et génère la suivante
     *
     * @param int $numero Numéro de la salle complétée
     * @return RedirectResponse
     */
    public function valider($numero): RedirectResponse
    {
        // contrôle sur le numéro de salle
        if (!$this->salleValide($numero)) {
            return redirect()->to('/')
                ->with('error', 'Numéro de salle invalide');
        }

        // Marque la salle comme complétée
        $this->ajouteSalleComplete($numero);

        // Détermine la prochaine salle
        $nextRoom = $this->getSalleSuivante();

        // Toutes les salles sont complétées
        if ($nextRoom === null) {
            session()->set(self::SESSION_CURRENT_ROOM, -1);
            return redirect()->to('/')
                ->with('success', 'Félicitations ! Vous avez terminé toutes les salles !');
        }

        // Stocke la prochaine salle
        session()->set(self::SESSION_CURRENT_ROOM, $nextRoom);

        return redirect()->to('/')
            ->with('success', "Salle {$numero} complétée ! Direction la salle {$nextRoom}.");

    }

    /**
     * Valide la salle en mode jour
     *
     * @param int $numero Numéro de la salle complétée
     * @return RedirectResponse
     */
    public function validerJour($numero): RedirectResponse
    {
        // contrôle sur le numéro de salle
        if (!$this->salleValide($numero)) {
            return redirect()->to('manoirJour')
                ->with('error', 'Numéro de salle invalide');
        }

        // Marque la salle comme complétée
        $this->ajouteSalleComplete($numero);

        return redirect()->to('manoirJour')
            ->with('success', "Salle {$numero} complétée !");
    }

    public function echouerJour($numero): RedirectResponse
    {
        if (!$this->salleValide($numero)) {
            return redirect()->to('manoirJour')
                ->with('error', 'Numéro de salle invalide');
        }

        // Marque la salle comme échouée
        $this->ajouteSalleEchouee($numero);
        log_message('warning', 'salle échouée --echouerJour-- : ' . $numero);

        return redirect()->to('manoirJour')
            ->with('error', "Salle {$numero} échouée !");
    }

    /**
     * Réinitialise la progression du joueur
     *
     * @return RedirectResponse
     */
    public function reset(): RedirectResponse
    {
        session()->remove(self::SESSION_CURRENT_ROOM);
        session()->remove(self::SESSION_COMPLETED_ROOMS);
        session()->remove('mode');
        return redirect()->to('/')
            ->with('success', 'Parcours réinitialisé ! Bonne chance !');
    }

    /**
     * Réinitialise la progression du joueur
     *
     * @return RedirectResponse
     */
    public function resetSalleJour(): RedirectResponse
    {
        session()->remove(self::SESSION_CURRENT_ROOM);
        session()->remove(self::SESSION_COMPLETED_ROOMS);
        session()->remove(self::SESSION_FAILED_ROOMS);

        return redirect()->to('/manoirJour');
    }


    /*  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /*                         méthodes privées ... internes donc ...                         */
    /*  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    /**
     * Initialise les données de session si nécessaire
     *
     * @return void
     */
    private function initSession(): void
    {
        if (!session()->has(self::SESSION_CURRENT_ROOM)) {
            session()->set(self::SESSION_CURRENT_ROOM, rand(self::MIN_ROOM, self::MAX_ROOM));
        }

        if (!session()->has(self::SESSION_COMPLETED_ROOMS)) {
            session()->set(self::SESSION_COMPLETED_ROOMS, []);
        }

        if (!session()->has(self::SESSION_FAILED_ROOMS)) {
            session()->set(self::SESSION_FAILED_ROOMS, []);
        }

    }

    /**
     * Vérifie si un numéro de salle est valide
     *
     * @param int $numero Numéro de salle à vérifier
     * @return bool
     */
    private function salleValide(int $numero): bool
    {
        return $numero >= self::MIN_ROOM && $numero <= self::MAX_ROOM;
    }

    /**
     * Vérifie si une vue existe
     *
     * @param string $viewPath Chemin de la vue
     * @return bool
     */
    private function controleExisteView(string $viewPath): bool
    {
        $viewFile = APPPATH . 'Views/' . $viewPath . '.php';
        return file_exists($viewFile);
    }

    /**
     * Marque (ajoute) une salle comme complétée
     *
     * @param int $numero Numéro de la salle à marquer
     * @return void
     */
    private function ajouteSalleComplete(int $numero): void
    {
        $completed = session()->get(self::SESSION_COMPLETED_ROOMS) ?? [];

        if (!in_array($numero, $completed, true)) {
            $completed[] = $numero;
            session()->set(self::SESSION_COMPLETED_ROOMS, $completed);

        }
        // Retirer de failed_rooms si présent
        $failed = session()->get(self::SESSION_FAILED_ROOMS) ?? [];
        if (($key = array_search($numero, $failed, true)) !== false) {
            unset($failed[$key]);
            // ré-indexer le tableau pour éviter les trous
            $failed = array_values($failed);
            session()->set(self::SESSION_FAILED_ROOMS, $failed);
        }
    }

    /**
     * Marque (ajoute) une salle comme échouée
     *
     * @param int $numero Numéro de la salle à marquer
     * @return void
     */
    private function ajouteSalleEchouee(int $numero): void
    {
        $failed = session()->get(self::SESSION_FAILED_ROOMS) ?? [];
        if (!in_array($numero, $failed, true)) {
            $failed[] = $numero;
            session()->set(self::SESSION_FAILED_ROOMS, $failed);
        }
        // Retirer de completed_rooms si présent
        $completed = session()->get(self::SESSION_COMPLETED_ROOMS) ?? [];
        if (($key = array_search($numero, $completed, true)) !== false) {
            unset($completed[$key]);
            // ré-indexer le tableau pour éviter les "trous"
            $completed = array_values($completed);
            session()->set(self::SESSION_COMPLETED_ROOMS, $completed);
        }
    }


    /**
     * Détermine la prochaine salle aléatoire parmi celles non complétées
     * constantes définies à 1 en min et 6 en max
     * @return int|null Numéro de la prochaine salle ou null si toutes sont complétées
     */
    private function getSalleSuivante(): ?int
    {
        $completed = session()->get(self::SESSION_COMPLETED_ROOMS) ?? [];
        $allRooms = range(self::MIN_ROOM, self::MAX_ROOM);
        $remainingRooms = array_diff($allRooms, $completed);

        if (empty($remainingRooms)) {
            return null;
        }

        return $remainingRooms[array_rand($remainingRooms)];
    }
}

