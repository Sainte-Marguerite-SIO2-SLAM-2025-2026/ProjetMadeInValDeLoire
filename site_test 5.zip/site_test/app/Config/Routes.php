<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'HomeControlleur::index');
$routes->get('/manoirJour', 'HomeControlleur::pagejour');

$routes->get('/reset', 'HomeControlleur::reset');
$routes->get('/resetSalleJour', 'HomeControlleur::resetSalleJour');
$routes->get('/salle/salle_(:num)', 'HomeControlleur::salle/$1');
$routes->post('/valider/(:num)', 'HomeControlleur::valider/$1');
$routes->post('/validerJour/(:num)', 'HomeControlleur::validerJour/$1');
$routes->post('/echouerJour/(:num)', 'HomeControlleur::echouerJour/$1');


$routes->group('quiz', function($routes) {
    $routes->get('/', 'QuizControlleur::index');
    $routes->post('demarrer', 'QuizControlleur::demarrer');
    $routes->get('question', 'QuizControlleur::question');
    $routes->post('repondre', 'QuizControlleur::repondre');
    $routes->get('resultats', 'QuizControlleur::resultats');
    $routes->post('signaler-erreur', 'QuizControlleur::signalerErreur');
});