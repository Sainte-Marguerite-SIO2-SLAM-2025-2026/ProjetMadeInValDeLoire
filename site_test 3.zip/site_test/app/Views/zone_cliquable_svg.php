<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plan de Maison Interactif SVG</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .plan-container {
            text-align: center;
            margin: 20px 0;
        }

        svg {
            max-width: 100%;
            height: auto;
            border: 2px solid #ddd;
            border-radius: 8px;
        }

        /* Styles pour les pièces */
        .piece {
            /*fill: #e0e0e0;*/
            /*stroke: #333;*/
            /*stroke-width: 2;*/
            /*cursor: pointer;*/
            /*transition: all 0.3s ease;*/
            position: absolute;
            top: 100px; /* adapte selon ton besoin */
            left: 200px;
            width: 300px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.4);
            transition: opacity 0.3s ease-in-out;
            opacity: 0;
        }

        .piece.show{
            opacity: 1;
        }
        .piece:hover {
            /*fill: #00ffb2;*/
            background-image: url('<?= base_url("image/salles/salle_1.webp") ?>');
            background-size: cover;
            background-repeat: no-repeat;
            /*opacity: 0.9;*/
            /*filter: brightness(2.75);*/
        }

        svg path {s
            cursor: pointer;
            fill: none;
            stroke: #999;
            stroke-width: 2;
            transition: all 0.2s ease;
        }
        svg path:hover {
            stroke: #ffcc00;
            stroke-width: 5;
            filter: drop-shadow(0 0 6px #ffdd00);
        }
        .piece.highlighted {
            /*stroke: #f0ff2f; !* couleur du contour lumineux *!*/
            /*stroke-width: 6;*/
            fill: none !important; /* on garde l’intérieur transparent */
            /*filter: drop-shadow(0 0 6px #c1d7d8);*/
            /*animation: pulse 1.5s infinite;*/
            border: 4px solid #fff;
            border-radius: 12px;
            box-shadow:
                    0 0 8px #fff,
                    inset 0 0 8px #fff,
                    0 0 16px #37f713,
                    inset 0 0 16px #37f713,
                    0 0 32px #37f713,
                    inset 0 0 32px #37f713;

        }

        @keyframes pulse-svg {
            0% { stroke-width: 2; filter: drop-shadow(0 0 0px #00eaff); }
            50% { stroke-width: 4; filter: drop-shadow(0 0 6px #00eaff); }
            100% { stroke-width: 2; filter: drop-shadow(0 0 0px #00eaff); }
        }

        /* Labels des pièces */
        .piece-label {
            fill: #333;
            font-size: 14px;
            font-weight: bold;
            pointer-events: none;
            text-anchor: middle;
        }

        .info-box {
            margin-top: 20px;
            padding: 15px;
            background: #e8f4f8;
            border-left: 4px solid #2196F3;
            border-radius: 4px;
        }

        .info-box.success {
            background: #e8f5e9;
            border-left-color: #4CAF50;
        }

        .info-box strong {
            color: #1976D2;
        }

        .legend {
            margin-top: 20px;
            padding: 15px;
            background: #fff3e0;
            border-radius: 4px;
        }

        .legend h3 {
            margin-top: 0;
            color: #f57c00;
        }

        .legend ul {
            list-style: none;
            padding: 0;
        }

        .legend li {
            padding: 5px 0;
            color: #666;
        }

        .button-container {
            text-align: center;
            margin: 20px 0;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #1976D2;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>🏠 Plan de Maison Interactif (SVG)</h1>

    <div class="info-box" id="infoBox">
        <strong>Pièce mise en lumière :</strong> <span id="highlightedRoom"></span>
    </div>

    <div class="plan-container">
        <?php
        // Chargement du fichier SVG
        $svgPath = FCPATH . 'svg/manoir_nuit_2.svg';
        if (file_exists($svgPath)) {
            echo file_get_contents($svgPath);
        } else {
            echo var_dump($svgPath).'<p style="color: red;">Erreur : Fichier SVG introuvable</p>';
        }
        ?>
<!--        <!-- Plan SVG de la maison -->-->
<!--        <svg id="houseMap" viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">-->
<!--            <!-- Fond -->-->
<!--            <rect width="800" height="600" fill="#f9f9f9"/>-->
<!---->
<!--            <!-- SOUS-SOL -->-->
<!--            <polygon id="sous-sol" class="piece"-->
<!--                     data-piece="Sous-sol"-->
<!--                     points="50,450 250,450 250,550 50,550"/>-->
<!--            <text class="piece-label" x="150" y="505">Sous-sol</text>-->
<!---->
<!--            <!-- REZ-DE-CHAUSSÉE - Cuisine -->-->
<!--            <polygon id="cuisine" class="piece"-->
<!--                     data-piece="Cuisine"-->
<!--                     points="50,300 250,300 250,430 50,430"/>-->
<!--            <text class="piece-label" x="150" y="370">Cuisine</text>-->
<!---->
<!--            <!-- REZ-DE-CHAUSSÉE - Salon -->-->
<!--            <polygon id="salon" class="piece"-->
<!--                     data-piece="Salon"-->
<!--                     points="270,300 550,300 550,430 270,430"/>-->
<!--            <text class="piece-label" x="410" y="370">Salon</text>-->
<!---->
<!--            <!-- ÉTAGE - Chambre 1 -->-->
<!--            <polygon id="chambre1" class="piece"-->
<!--                     data-piece="Chambre 1"-->
<!--                     points="50,150 250,150 250,280 50,280"/>-->
<!--            <text class="piece-label" x="150" y="220">Chambre 1</text>-->
<!---->
<!--            <!-- ÉTAGE - Chambre 2 -->-->
<!--            <polygon id="chambre2" class="piece"-->
<!--                     data-piece="Chambre 2"-->
<!--                     points="270,150 550,150 550,280 270,280"/>-->
<!--            <text class="piece-label" x="410" y="220">Chambre 2</text>-->
<!---->
<!--            <!-- GRENIER -->-->
<!--            <polygon id="grenier" class="piece"-->
<!--                     data-piece="Grenier"-->
<!--                     points="570,80 750,80 750,200 570,200"/>-->
<!--            <text class="piece-label" x="660" y="145">Grenier</text>-->
<!---->
<!--            <!-- Lignes de structure (optionnel) -->-->
<!--            <line x1="0" y1="140" x2="800" y2="140" stroke="#999" stroke-width="1" stroke-dasharray="5,5"/>-->
<!--            <line x1="0" y1="290" x2="800" y2="290" stroke="#999" stroke-width="1" stroke-dasharray="5,5"/>-->
<!--            <line x1="0" y1="440" x2="800" y2="440" stroke="#999" stroke-width="1" stroke-dasharray="5,5"/>-->
<!--        </svg>-->

        <img id="piecePreview" class="piece hidden" src="<?= base_url('image/salles/salle_1.webp') ?>" alt="Salle 1">
    </div>
    </div>

    <div class="button-container">
        <button id="changeRoomBtn">🔄 Changer la pièce en lumière</button>
    </div>

    <div class="legend">
        <h3>📋 Instructions</h3>
        <ul>
            <li>✨ Une pièce est automatiquement mise en lumière au chargement</li>
            <li>🖱️ Survolez les pièces pour voir l'effet de survol</li>
            <li>👆 Cliquez sur une pièce pour l'identifier</li>
            <li>🔄 Utilisez le bouton pour changer aléatoirement la pièce en lumière</li>
        </ul>
    </div>
</div>

<script>
    // Récupération des éléments
    const pieces = document.querySelectorAll('.piece');
    const infoBox = document.getElementById('infoBox');
    const highlightedRoomSpan = document.getElementById('highlightedRoom');
    const changeRoomBtn = document.getElementById('changeRoomBtn');

    // Fonction pour mettre en lumière une pièce aléatoire
    function highlightRandomRoom() {
        // Retirer la mise en lumière existante
        pieces.forEach(p => p.classList.remove('highlighted'));

        // Choisir une pièce au hasard
        const randomIndex = Math.floor(Math.random() * pieces.length);
        const randomPiece = pieces[randomIndex];

        // Appliquer la mise en lumière
        randomPiece.classList.add('highlighted');

        // Afficher le nom de la pièce
        const pieceName = randomPiece.getAttribute('data-piece');
        highlightedRoomSpan.textContent = pieceName;

        console.log('Pièce mise en lumière:', pieceName);
    }

    // Gestionnaire de clic sur les pièces
    pieces.forEach(piece => {
        piece.addEventListener('click', function(e) {
            const pieceName = this.getAttribute('data-piece');

            // Retirer la mise en lumière de toutes les pièces
            pieces.forEach(p => p.classList.remove('highlighted'));

            // Mettre en lumière la pièce cliquée
            this.classList.add('highlighted');

            // Mettre à jour l'info box
            infoBox.classList.add('success');
            highlightedRoomSpan.textContent = pieceName;

            // Log dans la console
            console.log('Pièce cliquée:', pieceName);
            console.log('ID de l\'élément:', this.id);

            // Retirer la classe success après 2 secondes
            setTimeout(() => {
                infoBox.classList.remove('success');
            }, 2000);
        });
    });

    // Bouton pour changer la pièce
    changeRoomBtn.addEventListener('click', highlightRandomRoom);

    // Mise en lumière aléatoire au chargement
    window.addEventListener('load', function() {
        highlightRandomRoom();
    });


    // Alternative: Si vous voulez envoyer l'info au serveur via AJAX
    function sendRoomToServer(roomName, roomId) {
        // Exemple avec fetch API
        /*
        fetch('/maison/roomClicked', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                room: roomName,
                id: roomId
            })
        })
        .then(response => response.json())
        .then(data => console.log('Réponse serveur:', data))
        .catch(error => console.error('Erreur:', error));
        */
    }
</script>
</body>
</html>