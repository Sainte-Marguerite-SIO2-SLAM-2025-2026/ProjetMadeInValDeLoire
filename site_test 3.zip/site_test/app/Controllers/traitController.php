<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class traitController extends BaseController
{

    public function index():string
    {
        return view('zone_cliquable_svg_v2');
        //return view('traitrougeFondCss');
    }
}