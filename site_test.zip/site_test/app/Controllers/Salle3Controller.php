<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Salle3Controller extends Controller
{
    public function salle($id)
    {
        $mode = session()->get('mode') ?? 'jour'; // default

        return view('salle', [
            'mode' => $mode,
            'id'   => $id
        ]);
    }

}