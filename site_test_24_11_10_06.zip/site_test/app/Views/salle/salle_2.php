<!DOCTYPE html>
<html>
<head>
    <title>Salle 5 </title>
</head>
<body>
<h1>Salle 2</h1>
<?php
$session = session(); ?>
<h3>Un coucou de la salle 2</h3>
<?php
if (session()->get('mode') === 'nuit') : ?>
    <p>Un coucou du mode PARCOURS</p>
    <!-- Bouton de test pour valider -->
    <form method="post" action="<?= base_url('valider/2') ?>">
        <?= csrf_field() ?>
        <button type="submit" style="padding: 15px 30px; font-size: 18px;">
            ✓ Valider la salle
        </button>
    </form>
    <br><br>
<?php elseif (session()->get('mode') === 'jour') : ?>
    <p>Un coucou du mode JOUR</p>
    <form method="post" action="<?= base_url('validerJour/2') ?>">
        <?= csrf_field() ?>
        <button type="submit" style="padding: 15px 30px; font-size: 18px;">
            ✓ Valider la salle mode Jour
        </button>
    </form>
    <form method="post" action="<?= base_url('echouerJour/2') ?>">
        <?= csrf_field() ?>
        <button type="submit" style="padding: 15px 30px; font-size: 18px;">
            ✗ Échouer la salle
        </button>
    </form>
    <br><br>
<?php endif; ?>
</body>
</html>