<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'HomeControlleur::index');
$routes->get('/manoirJour', 'HomeControlleur::pagejour');

$routes->get('/reset', 'HomeControlleur::reset');
$routes->get('/resetSalleJour', 'HomeControlleur::resetSalleJour');
$routes->get('/salle/salle_(:num)', 'HomeControlleur::salle/$1');
$routes->post('/valider/(:num)', 'HomeControlleur::valider/$1');
$routes->post('/validerJour/(:num)', 'HomeControlleur::validerJour/$1');
$routes->post('/echouerJour/(:num)', 'HomeControlleur::echouerJour/$1');


$routes->group('quiz', function($routes) {
    $routes->get('/', 'QuizControlleur::index');
    $routes->match(['get', 'post'],'demarrer/(:segment)', 'QuizControlleur::choix/$1');
    $routes->get('choix/(:segment)', 'QuizControlleur::demarrer/$1');
    $routes->get('question/(:segment)', 'QuizControlleur::question/$1');
    $routes->post('repondre/(:segment)', 'QuizControlleur::repondre/$1');
    $routes->get('resultats/(:segment)', 'QuizControlleur::resultats/$1');

});