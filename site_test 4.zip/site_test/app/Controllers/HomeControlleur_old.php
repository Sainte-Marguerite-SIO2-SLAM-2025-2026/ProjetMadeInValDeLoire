<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class HomeControlleur_old extends BaseController
{

    // Constantes de configuration
    private const MIN_ROOM = 1;
    private const MAX_ROOM = 6;

    // Clés de session
    private const SESSION_CURRENT_ROOM = 'current_room';
    private const SESSION_COMPLETED_ROOMS = 'completed_rooms';

    /**
     * Page d'accueil du manoir
     *
     * @return string
     */
    public function index(): string
    {
        $this->initializeSession();

        $data = [
            'current_room' => session()->get(self::SESSION_CURRENT_ROOM),
            'completed_rooms' => session()->get(self::SESSION_COMPLETED_ROOMS)
        ];

        return view('manoir_home', $data);
    }

    /**
     * Page du mode jour
     *
     * @return string
     */
    public function pagejour(): string
    {
        return view('manoir_jour_home');
    }

    /**
     * Affiche une salle spécifique
     *
     * @param int $numero Numéro de la salle
     * @return string|RedirectResponse
     */
    public function salle($numero) : string|RedirectResponse
    {
        // Vérifie que le numéro de salle est valide
        if ($numero < 1 || $numero > 6) {
            return redirect()->to('/');
        }
        $data['numero_salle'] = $numero;
        // Charge la vue spécifique de la salle
        return view("/salle_{$numero}", $data);
    }

    public function valider($numero)
    {
        // Récupère les salles complétées depuis la session
        $completed = session()->get('completed_rooms') ?? [];
        // Marque la salle actuelle comme complétée
        if (!in_array($numero, $completed)) {
            $completed[] = $numero;
            session()->set('completed_rooms', $completed);
        }
        // Liste de toutes les salles
        $all_rooms = range(1, 6);
        // Filtre les salles non complétées
        $remaining_rooms = array_diff($all_rooms, $completed);
        if (!empty($remaining_rooms)) {
            // Choisit une salle aléatoire parmi celles restantes
            $next_room = $remaining_rooms[array_rand($remaining_rooms)];
        } else {
            // Toutes les salles sont complétées affectation de -1 car le null pose pb...
            // et pas de salle -1
            $next_room = -1;
        }
        // Stocke la prochaine salle dans la session
        session()->set('current_room', $next_room);
        // Retour au manoir avec message de succès
        return redirect()->to('/')->with('success', "Salle $numero complétée !");
    }

    public function validerJour($numero)
    {
        // Marque la salle comme complétée
        $completed = session()->get('completed_rooms') ?? [];
        if (!in_array($numero, $completed)) {
            $completed[] = $numero;
            session()->set('completed_rooms', $completed);
        }
        // Retour au manoir avec message de succès
        return redirect()->to('/manoirJour')->with('success', "Salle $numero complétée !");
    }

    public function reset()
    {
        // Efface toutes les données de progression
        session()->remove('current_room');
        session()->remove('completed_rooms');

        // Redirige vers le manoir (qui réinitialisera une salle aléatoire)
        return redirect()->to('/')->with('success', 'Parcours réinitialisé ! Bonne chance !');
    }
}