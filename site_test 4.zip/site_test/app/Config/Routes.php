<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'HomeControlleur::index');
$routes->get('/manoirJour', 'HomeControlleur::pagejour');

$routes->get('/reset', 'HomeControlleur::reset');
$routes->get('/salle/salle_(:num)', 'HomeControlleur::salle/$1');
$routes->post('/valider/(:num)', 'HomeControlleur::valider/$1');
$routes->post('/validerJour/(:num)', 'HomeControlleur::validerJour/$1');