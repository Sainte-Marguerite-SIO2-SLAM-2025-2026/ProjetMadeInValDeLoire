<!DOCTYPE html>
<html>
<head>
    <title>Salle 2 </title>
</head>
<body>
<h1>Salle 2</h1>

<p>Un coucou de la salle 2</p>

<!-- Bouton de test pour valider -->
<form method="post" action="<?= base_url('valider/2') ?>">
    <?= csrf_field() ?>
    <button type="submit" style="padding: 15px 30px; font-size: 18px;">
        ✓ Valider la salle
    </button>
</form>
<br><br>

<form method="post" action="<?= base_url('validerJour/2') ?>">
    <?= csrf_field() ?>
    <button type="submit" style="padding: 15px 30px; font-size: 18px;">
        ✓ Valider la salle mode Jour
    </button>
</form>

<br><br>
</body>
</html>