<!DOCTYPE html>
<html>
<head>
    <title>Salle 5 </title>
</head>
<body>
<h1>Salle 5</h1>

<p>Un coucou de la salle 5</p>

<!-- Bouton de test pour valider -->
<form method="post" action="<?= base_url('valider/5') ?>">
    <?= csrf_field() ?>
    <button type="submit" style="padding: 15px 30px; font-size: 18px;">
        ✓ Valider la salle
    </button>
</form>
<br><br>

<form method="post" action="<?= base_url('validerJour/5') ?>">
    <?= csrf_field() ?>
    <button type="submit" style="padding: 15px 30px; font-size: 18px;">
        ✓ Valider la salle mode Jour
    </button>
</form>
<br><br>
</body>
</html>