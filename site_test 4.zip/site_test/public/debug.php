<?php
echo "PHP Error Reporting: " . error_reporting() . "<br>";
echo "Display Errors: " . ini_get('display_errors') . "<br>";
echo "CI Environment: " . ($_SERVER['CI_ENVIRONMENT'] ?? 'non défini') . "<br>";
echo "ENVIRONMENT constant: " . (defined('ENVIRONMENT') ? ENVIRONMENT : 'non défini') . "<br>";

// Test d'erreur volontaire
$undefined_variable = $this_does_not_exist;
?>